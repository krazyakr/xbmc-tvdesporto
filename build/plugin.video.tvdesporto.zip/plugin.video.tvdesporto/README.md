xbmc-tvdesporto
===============

XBMC Addon TV Desporto
by krazyakr

This project aims to create a XBMC video plugin to show and live stream Premium Portuguese Sports TV Channels.

